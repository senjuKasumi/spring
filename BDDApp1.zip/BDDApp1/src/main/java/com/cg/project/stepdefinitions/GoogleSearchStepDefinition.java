package com.cg.project.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class GoogleSearchStepDefinition {
	
	WebDriver driver;

	@Given("^User is on Google HomePage$")
	public void user_is_on_Google_HomePage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://www.google.com/");
	}

	@When("^User search for 'Agile Methodology'$")
	public void user_search_for_Agile_Methodology() throws Throwable {
		By by = By.name("q");
		WebElement searchTxt = driver.findElement(by);
		searchTxt.sendKeys("Agile Methodology");
		searchTxt.submit();
	}

	@Then("^All links should display with 'Agile Methodology'$")
	public void all_links_should_display_with_Agile_Methodology() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "AgileMethodology - Google Search";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
/*
	@When("^User search for 'Agile Methodology videos'$")
	public void user_search_for_Agile_Methodology_videos() throws Throwable {
	}

	@Then("^Only video links on 'Agile Methodology' should be given to the user$")
	public void only_video_links_on_Agile_Methodology_should_be_given_to_the_user() throws Throwable {
	}

	@When("^User search for 'Agile Methodology pdf'$")
	public void user_search_for_Agile_Methodology_pdf() throws Throwable {
	}

	@Then("^Only pdf file links on 'Agile Methodology' should be given to the user$")
	public void only_pdf_file_links_on_Agile_Methodology_should_be_given_to_the_user() throws Throwable {
	}*/
}
