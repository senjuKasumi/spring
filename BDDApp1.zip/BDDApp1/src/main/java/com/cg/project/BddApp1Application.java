package com.cg.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BddApp1Application {

	public static void main(String[] args) {
		SpringApplication.run(BddApp1Application.class, args);
	}
}
