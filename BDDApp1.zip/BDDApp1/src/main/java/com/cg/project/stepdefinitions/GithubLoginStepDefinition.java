package com.cg.project.stepdefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class GithubLoginStepDefinition {
	
	private WebDriver driver;
	private LoginPage loginPage;

	@Given("^user is in the login page$")
	public void user_is_in_the_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^user enters wrong password and correct username$")
	public void user_enters_wrong_password_and_correct_username() throws Throwable {
		loginPage.setUsername("senjuKasumi");
		loginPage.setPassword("Parul");
		loginPage.clickSignIn();
	}

	@Then("^display \"([^\"]*)\" message in the same page$")
	public void display_message_in_the_same_page(String arg1) throws Throwable {
		String expectedErrorMessage = "Incorrect username or password";
		Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
		driver.close();
	}

	@When("^user enters correct password and correct username$")
	public void user_enters_correct_password_and_correct_username() throws Throwable {
		loginPage.setUsername("senjuKasumi");
		loginPage.setPassword("Parul@1206");
		loginPage.clickSignIn();
	}

	@Then("^displays the account$")
	public void displays_the_account() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Github";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
