package com.cg.mobilebilling.stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.beans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class billingRegistrationStepDefinition {
	
	private WebDriver driver;
	private RegistrationPage registrationPage;

	@Given("^customer is in the registration page$")
	public void customer_is_in_the_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:3544/registration");
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	}

	@When("^customer clicks submit without entering firstname$")
	public void customer_clicks_submit_without_entering_firstname() throws Throwable {
		registrationPage.setFirstName("");
		registrationPage.submit();
	}

	@Then("^display \"([^\"]*)\" message in the same page$")
	public void display_message_in_the_same_page(String arg1) throws Throwable {
		String expectedErrorMessage = "must not be empty";
		Assert.assertEquals(expectedErrorMessage, registrationPage.getFirstnameErrorMessage());
		driver.close();
	}

	@When("^customer clicks submit without entering lastname$")
	public void customer_clicks_submit_without_entering_lastname() throws Throwable {
		registrationPage.setLastName("");
		registrationPage.submit();
	}

	@When("^customer clicks submit without entering emailId$")
	public void customer_clicks_submit_without_entering_emailId() throws Throwable {
		registrationPage.setEmailID("");
		registrationPage.submit();
	}

	@When("^customer clicks submit without entering date of birth$")
	public void customer_clicks_submit_without_entering_date_of_birth() throws Throwable {
		registrationPage.setDateOfBirth("");
		registrationPage.submit();
	}

	@When("^customer clicks submit with all information$")
	public void customer_clicks_submit_with_all_information() throws Throwable {
		registrationPage.setFirstName("Shraddha");
		registrationPage.setLastName("Singh");
		registrationPage.setEmailID("shraddha@com");
		registrationPage.setDateOfBirth("12/06/95");
		registrationPage.submit();
	}

	@Then("^display registration success page$")
	public void display_registration_success_page() throws Throwable {
		String actualTitle = driver.getTitle();
		String expectedTitle = "Controller Advisor";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
