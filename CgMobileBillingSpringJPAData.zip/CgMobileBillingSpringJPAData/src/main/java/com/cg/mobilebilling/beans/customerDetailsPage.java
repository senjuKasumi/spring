package com.cg.mobilebilling.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import gherkin.lexer.Fi;

public class customerDetailsPage {

	@FindBy(how=How.NAME,name="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME,name="mobileNo")
	private WebElement mobileNo;

	@FindBy(how=How.NAME,name="Submit")
	private WebElement submit;
	
	@FindBy(how=How.ID,id="message2")
	private WebElement errorMessage;
	
	
}
