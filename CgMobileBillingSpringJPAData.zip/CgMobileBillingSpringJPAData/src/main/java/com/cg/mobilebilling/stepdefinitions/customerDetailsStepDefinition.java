package com.cg.mobilebilling.stepdefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class customerDetailsStepDefinition {

	@Given("^customer is in the customer details page$")
	public void customer_is_in_the_customer_details_page() throws Throwable {
	}

	@When("^customer enters wrong customerId and clicks submit$")
	public void customer_enters_wrong_customerId_and_clicks_submit() throws Throwable {
	}

	@Then("^display \"([^\"]*)\"messageA$")
	public void display_messageA(String arg1) throws Throwable {
	}

	@When("^customer enters wrong mobileNo and clicks submit$")
	public void customer_enters_wrong_mobileNo_and_clicks_submit() throws Throwable {
	}

	@Then("^display \"([^\"]*)\"messageB$")
	public void display_messageB(String arg1) throws Throwable {
	}

	@When("^customer enters correct details and clicks submit$")
	public void customer_enters_correct_details_and_clicks_submit() throws Throwable {
	}

	@Then("^display customer details$")
	public void display_customer_details() throws Throwable {
	}
}
