package com.cg.mobilebilling.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.beans.MonthlyBillPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class monthlyBillStepDefinition {

	private WebDriver driver;
	private MonthlyBillPage monthlyBillPage;

	@Given("^customer is on generate bill page$")
	public void customer_is_on_generate_bill_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:3544/getMonthlyBill");
		monthlyBillPage=PageFactory.initElements(driver, MonthlyBillPage.class);
	}

	@When("^customer enters non existent customerID$")
	public void customer_enters_non_existent_customerID() throws Throwable {
		monthlyBillPage.setCustomerID("1234");
		monthlyBillPage.setMobileNo("987650001");
		monthlyBillPage.Submit();
	}

	@Then("^display \"([^\"]*)\" messageA$")
	public void display_messageA(String arg1) throws Throwable {
		String expectedMessage="Customer details for the entered customerID not found";
		Assert.assertEquals(expectedMessage, monthlyBillPage.getErrorMessage());
		driver.close();
	}

	@When("^customer enters non existent mobileNo$")
	public void customer_enters_non_existent_mobileNo() throws Throwable {
		monthlyBillPage.setCustomerID("101");
		monthlyBillPage.setMobileNo("54541434");
		monthlyBillPage.Submit();
	}

	@Then("^display \"([^\"]*)\" messageB$")
	public void display_messageB(String arg1) throws Throwable {
		String expectedMessage="Postpaid account for the entered number not found";
		Assert.assertEquals(expectedMessage, monthlyBillPage.getErrorMessage());
		driver.close();
	}
	@When("^customer enters valid details$")
	public void customer_enters_valid_details() throws Throwable {
		monthlyBillPage.setCustomerID("101");
		monthlyBillPage.setMobileNo("987650001");
		monthlyBillPage.Submit();
	}

	@Then("^display bill$")
	public void display_bill() throws Throwable {
		String expectedTitle= "Monthly Bill";
		Assert.assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}
}
