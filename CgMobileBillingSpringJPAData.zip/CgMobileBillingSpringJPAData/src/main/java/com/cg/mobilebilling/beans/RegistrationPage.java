package com.cg.mobilebilling.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {

	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName;

	@FindBy(how=How.ID,id="lastName")
	private WebElement lastName;

	@FindBy(how=How.ID,id="emailID")
	private WebElement emailID;

	@FindBy(how=How.ID,id="dateOfBirth")
	private WebElement dateOfBirth;

	@FindBy(how=How.NAME,name="submit")
	private WebElement button;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"firstName.errors\"]")
	private WebElement firstnameErrorMessage;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"lastName.errors\"]")
	private WebElement lastnameErrorMessage;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"emailID.errors\"]")
	private WebElement emailIDErrorMessage;

	@FindBy(how=How.XPATH,xpath="//*[@id=\"dateOfBirth.errors\"]")
	private WebElement dateOfBirthErrorMessage;

	public RegistrationPage() {}

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstname) {
		this.firstName.sendKeys(firstname);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastname) {
		this.lastName.sendKeys(lastname);
	}
	
	public String getEmailID() {
		return emailID.getAttribute("value");
	}

	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}
	
	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}

	public String getFirstnameErrorMessage() {
		return firstnameErrorMessage.getText();
	}

	public String getLastnameErrorMessage() {
		return lastnameErrorMessage.getText();
	}
	
	public String getEmailIDErrorMessage() {
		return emailIDErrorMessage.getText();
	}
	
	public String getDateOfBirthErrorMessage() {
		return dateOfBirthErrorMessage.getText();
	}
	
	public void submit() {
		button.click();
	}
}
