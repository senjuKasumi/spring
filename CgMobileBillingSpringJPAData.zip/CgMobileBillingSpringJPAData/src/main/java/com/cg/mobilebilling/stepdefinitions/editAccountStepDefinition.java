package com.cg.mobilebilling.stepdefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.beans.EditAccountPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;

public class editAccountStepDefinition {

	private WebDriver driver;
	private EditAccountPage editAccountPage;

	@Given("^customer is in the display plans page$")
	public void customer_is_in_the_display_plans_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://localhost:3544/displayPlanDetails");
		editAccountPage=PageFactory.initElements(driver, EditAccountPage.class);
	}

	@When("^customer enters non existent customerId and clicks submit$")
	public void customer_enters_non_existent_customerId_and_clicks_submit() throws Throwable {
		editAccountPage.setCustomerID("111");
		editAccountPage.setPlanID("102");
		editAccountPage.Submit();
	}

	@Then("^display \"([^\"]*)\"message$")
	public void display_message(String arg1) throws Throwable {
		String expectedMessage="Customer details for the entered customerID not found";
		Assert.assertEquals(expectedMessage, editAccountPage.getErrorMessage());
	}

	@When("^customer enters non existent planId and clicks submit$")
	public void customer_enters_non_existent_planId_and_clicks_submit() throws Throwable {
		editAccountPage.setCustomerID("101");
		editAccountPage.setPlanID("123");
		editAccountPage.Submit();
	}

	@Then("^display \"([^\"]*)\"plan message$")
	public void display_plan_message(String arg1) throws Throwable {
//		driver.get("http://localhost:3544/enterBillDetails");
		String expectedMessage="Entered planId not found";
		Assert.assertEquals(expectedMessage,editAccountPage.getErrorMessage());	
	}

	@When("^customer enters valid details and clicks submit$")
	public void customer_enters_valid_details_and_clicks_submit() throws Throwable {
		editAccountPage.setCustomerID("101");
		editAccountPage.setPlanID("102");
		editAccountPage.Submit();
	}

	@Then("^display success page$")
	public void display_success_page() throws Throwable {
		String expectedTitle= "Controller Advisor";
		Assert.assertEquals(expectedTitle, driver.getTitle());
		driver.close();
	}
}
