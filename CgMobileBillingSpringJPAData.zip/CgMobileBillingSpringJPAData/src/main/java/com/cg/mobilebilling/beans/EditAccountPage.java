package com.cg.mobilebilling.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class EditAccountPage {

	@FindBy(how=How.ID,id="customerID")
	private WebElement customerID;
	
	@FindBy(how=How.NAME, name="planID")
	private WebElement planID;
	
	@FindBy(how=How.NAME,name="submit")
	private WebElement button;

	@FindBy(how=How.ID,id="message2")
	private WebElement errorMessage;
	
	public EditAccountPage() {}
	
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}
	
	public String getPlanID() {
		return planID.getAttribute("value");
	}
	
	public void setPlanID(String planID) {
		this.planID.sendKeys(planID);
	}
	
	public String getErrorMessage() {
		return this.errorMessage.getText();
	}
	
	public void Submit() {
		button.click();
	}
}
