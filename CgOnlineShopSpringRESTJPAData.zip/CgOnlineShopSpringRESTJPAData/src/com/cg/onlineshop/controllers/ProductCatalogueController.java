package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundexception;
import com.cg.onlineshop.service.OnlineShopServices;

@RestController
@CrossOrigin
public class ProductCatalogueController {

	@Autowired
	OnlineShopServices onlineServices;

	@RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
		ResponseEntity<String>response = new ResponseEntity<String>("Hello to all",HttpStatus.OK);
		return response;
	}

	@RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		onlineServices.acceptProductDetails(product);
		return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}

	@RequestMapping(value="/findProduct", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundexception{
		Product product=onlineServices.getProductDetails(productId);
		return new ResponseEntity<>(product, HttpStatus.OK);
	}

	@RequestMapping(value="/allProductDetails", produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetails(){
		List<Product> productsList=onlineServices.getAllProductDetails();
		return new ResponseEntity<>(productsList, HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeProduct", method=RequestMethod.DELETE)
	public ResponseEntity<String> removeProductDetails(@RequestParam("productId")int productId) throws ProductDetailsNotFoundexception{
		onlineServices.removeProductDetails(productId);
		return new ResponseEntity<>("Product details with productId"+productId+"successfully deleted", HttpStatus.OK);
	}
	
	@RequestMapping(value="/addBulkProductDetails",consumes=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public ResponseEntity<String>addBulkProductDetails(@RequestBody ArrayList<Product>products){
		for(Product product: products)
			onlineServices.acceptProductDetails(product);
		return new ResponseEntity<>("Products details successfully added",HttpStatus.OK);
	}
}