package com.cg.onlineshop.service;

import java.util.List;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundexception;

public interface OnlineShopServices {

	public Product acceptProductDetails(Product product);
	public List<Product>getAllProductDetails();
	public Product getProductDetails(int productId)throws ProductDetailsNotFoundexception;
	public void removeProductDetails(int productId);
}
