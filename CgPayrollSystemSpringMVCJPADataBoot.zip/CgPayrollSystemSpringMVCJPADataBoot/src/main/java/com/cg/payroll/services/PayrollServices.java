package com.cg.payroll.services;

import java.util.HashMap;
import java.util.List;

import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.beans.Associate;

public interface PayrollServices {
	Associate acceptAssociateDetails(Associate associate)throws PayrollServicesDownException;
	
	int calculateNetSalary(int associateId)throws AssociateDetailNotFoundException, PayrollServicesDownException;
	
	Associate getAssociateDetails(int associateId)throws AssociateDetailNotFoundException, PayrollServicesDownException;
	List<Associate> getAllAssociatesDetails()throws PayrollServicesDownException;
//	HashMap<Integer, Associate> getAllAssociateDetails()throws PayrollServicesDownException;
	
}
