package com.cg.payroll.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	
	@Autowired
	private AssociateDAO associateDAO;


	@Override
	public Associate acceptAssociateDetails(Associate associate) throws PayrollServicesDownException {
		//Associate associate = new Associate(associate); 
		
		associate=associateDAO.save(associate);
		
		return associate;
	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		Associate associate = getAssociateDetails(associateId);
			associate.getSalary().setHra((30*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setPersonalAllowance((25*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setConveyenceAllowance((10*associate.getSalary().getBasicSalary()/100));
			associate.getSalary().setGrossSalary((associate.getSalary().getBasicSalary()+associate.getSalary().getHra()
					+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getEpf()+associate.getSalary().getCompanyPf()));
			int annualGrossSalary = associate.getSalary().getGrossSalary() * 12;
			double netSalaryAfterInvesting = annualGrossSalary - ((associate.getYearlyInvestmentUnder80C()>(150000-(associate.getSalary().getEpf()*12)-(associate.getSalary().getCompanyPf()*12))?(150000):(associate.getYearlyInvestmentUnder80C() + (associate.getSalary().getEpf()*12) +(associate.getSalary().getCompanyPf()*12))));
			int annualTax = 0; 
			if(annualGrossSalary > 250000 && annualGrossSalary <= 500000)
				annualTax = (int) (.05 * (annualGrossSalary-250000));
			if(annualGrossSalary > 500000 && annualGrossSalary <= 1000000)
				annualTax = (int) (.05 * 250000 + .2 * (annualGrossSalary - 500000));
			if(annualGrossSalary > 1000000)
				annualTax = (int) (.05 * 250000 + .2 * 500000 + .3 * (annualGrossSalary - 1000000));
			associate.getSalary().setMonthlyTax(annualTax / 12);
			associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary() - associate.getSalary().getMonthlyTax() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf());
			associateDAO.save(associate);
			return associate.getSalary().getNetSalary();
		
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailNotFoundException,
			PayrollServicesDownException {
		Associate associate = associateDAO.findById(associateId).get();
		if(associate==null) throw new AssociateDetailNotFoundException("Associate Details Not Found");
		return associate;
	}

	@Override
	public List<Associate> getAllAssociatesDetails()throws PayrollServicesDownException {
			return associateDAO.findAll();
	}

}
